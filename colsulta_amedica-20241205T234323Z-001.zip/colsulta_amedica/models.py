from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False, unique=True)
    password = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), nullable=False, unique=True)
    tipo = db.Column(db.String(50), nullable=False)  # 'paciente' ou 'medico'

class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    especialidade = db.Column(db.String(100), nullable=False)
    crm = db.Column(db.String(50), nullable=False, unique=True)
    telefone = db.Column(db.String(15), nullable=True)

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    medico_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), nullable=False)
    data = db.Column(db.String(50), nullable=False)
    hora = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(50), default='agendada')  # 'agendada', 'cancelada', 'concluída'
    usuario = db.relationship('User ', backref='consultas')
    medico = db.relationship('Doctor', backref='consultas')

class MedicalHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    data = db.Column(db.String(50), nullable=False)
    usuario = db.relationship('User ', backref='historico_medico')

class Prescription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    consulta_id = db.Column(db.Integer, db.ForeignKey('appointment.id'), nullable=False)
    medicamento = db.Column(db.String(150), nullable=False)
    dosagem = db.Column(db.String(50), nullable=False)
    instrucoes = db.Column(db.Text, nullable=True)
    consulta = db.relationship('Appointment', backref='receitas')